create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  name text,
  sku text,
  factory text,
  factory_contact text,
  owner text,
  image_url text,
  start_date date,
  due_date date,
  status text,
  risk text,
  note text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

alter table public.products add column if not exists id uuid default gen_random_uuid();
alter table public.products add column if not exists user_id uuid;
alter table public.products add column if not exists name text;
alter table public.products add column if not exists sku text;
alter table public.products add column if not exists factory text;
alter table public.products add column if not exists factory_contact text;
alter table public.products add column if not exists owner text;
alter table public.products add column if not exists image_url text;
alter table public.products add column if not exists start_date date;
alter table public.products add column if not exists due_date date;
alter table public.products add column if not exists status text;
alter table public.products add column if not exists risk text;
alter table public.products add column if not exists note text;
alter table public.products add column if not exists created_at timestamptz default now();
alter table public.products add column if not exists updated_at timestamptz default now();
alter table public.products alter column id set default gen_random_uuid();
alter table public.products alter column created_at set default now();
alter table public.products alter column updated_at set default now();

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conrelid = 'public.products'::regclass and contype = 'p'
  ) then
    alter table public.products add constraint products_pkey primary key (id);
  end if;

  if not exists (
    select 1 from pg_constraint
    where conrelid = 'public.products'::regclass and conname = 'products_user_id_fkey'
  ) then
    alter table public.products
      add constraint products_user_id_fkey
      foreign key (user_id) references auth.users(id) on delete cascade;
  end if;
end $$;

create table if not exists public.product_logs (
  id uuid primary key default gen_random_uuid(),
  product_id uuid references public.products(id) on delete cascade,
  user_id uuid references auth.users(id) on delete cascade,
  log_date timestamptz,
  type text,
  content text,
  next_step text,
  deadline date,
  status text,
  note text,
  created_at timestamptz default now()
);

alter table public.product_logs add column if not exists id uuid default gen_random_uuid();
alter table public.product_logs add column if not exists product_id uuid;
alter table public.product_logs add column if not exists user_id uuid;
alter table public.product_logs add column if not exists log_date timestamptz;
alter table public.product_logs add column if not exists type text;
alter table public.product_logs add column if not exists content text;
alter table public.product_logs add column if not exists next_step text;
alter table public.product_logs add column if not exists deadline date;
alter table public.product_logs add column if not exists status text;
alter table public.product_logs add column if not exists note text;
alter table public.product_logs add column if not exists created_at timestamptz default now();
alter table public.product_logs alter column id set default gen_random_uuid();
alter table public.product_logs alter column created_at set default now();

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conrelid = 'public.product_logs'::regclass and contype = 'p'
  ) then
    alter table public.product_logs add constraint product_logs_pkey primary key (id);
  end if;

  if not exists (
    select 1 from pg_constraint
    where conrelid = 'public.product_logs'::regclass and conname = 'product_logs_product_id_fkey'
  ) then
    alter table public.product_logs
      add constraint product_logs_product_id_fkey
      foreign key (product_id) references public.products(id) on delete cascade;
  end if;

  if not exists (
    select 1 from pg_constraint
    where conrelid = 'public.product_logs'::regclass and conname = 'product_logs_user_id_fkey'
  ) then
    alter table public.product_logs
      add constraint product_logs_user_id_fkey
      foreign key (user_id) references auth.users(id) on delete cascade;
  end if;
end $$;

create index if not exists products_user_id_updated_at_idx
  on public.products (user_id, updated_at desc);

create index if not exists product_logs_user_product_log_date_idx
  on public.product_logs (user_id, product_id, log_date desc);

alter table public.products enable row level security;
alter table public.product_logs enable row level security;

create or replace function public.set_current_user_id()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;
  new.user_id := auth.uid();
  return new;
end;
$$;

drop trigger if exists products_set_current_user_id on public.products;
create trigger products_set_current_user_id
before insert on public.products
for each row execute function public.set_current_user_id();

drop trigger if exists product_logs_set_current_user_id on public.product_logs;
create trigger product_logs_set_current_user_id
before insert on public.product_logs
for each row execute function public.set_current_user_id();

drop policy if exists products_select_own on public.products;
drop policy if exists products_insert_own on public.products;
drop policy if exists products_update_own on public.products;
drop policy if exists products_delete_own on public.products;
drop policy if exists product_logs_select_own on public.product_logs;
drop policy if exists product_logs_insert_own on public.product_logs;
drop policy if exists product_logs_update_own on public.product_logs;
drop policy if exists product_logs_delete_own on public.product_logs;

create policy products_select_own on public.products
  for select to authenticated using (auth.uid() = user_id);

create policy products_insert_own on public.products
  for insert to authenticated with check (auth.uid() = user_id);

create policy products_update_own on public.products
  for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy products_delete_own on public.products
  for delete to authenticated using (auth.uid() = user_id);

create policy product_logs_select_own on public.product_logs
  for select to authenticated using (auth.uid() = user_id);

create policy product_logs_insert_own on public.product_logs
  for insert to authenticated with check (
    auth.uid() = user_id
    and exists (
      select 1 from public.products
      where products.id = product_logs.product_id
      and products.user_id = auth.uid()
    )
  );

create policy product_logs_update_own on public.product_logs
  for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy product_logs_delete_own on public.product_logs
  for delete to authenticated using (auth.uid() = user_id);

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'product-images',
  'product-images',
  true,
  5242880,
  array['image/png', 'image/jpeg', 'image/gif', 'image/webp']
)
on conflict (id) do update
set public = excluded.public,
    file_size_limit = excluded.file_size_limit,
    allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists product_images_select_public on storage.objects;
drop policy if exists product_images_insert_own_folder on storage.objects;
drop policy if exists product_images_update_own_folder on storage.objects;
drop policy if exists product_images_delete_own_folder on storage.objects;

create policy product_images_select_public on storage.objects
  for select using (bucket_id = 'product-images');

create policy product_images_insert_own_folder on storage.objects
  for insert to authenticated with check (
    bucket_id = 'product-images'
    and auth.uid()::text = (storage.foldername(name))[1]
  );

create policy product_images_update_own_folder on storage.objects
  for update to authenticated using (
    bucket_id = 'product-images'
    and auth.uid()::text = (storage.foldername(name))[1]
  ) with check (
    bucket_id = 'product-images'
    and auth.uid()::text = (storage.foldername(name))[1]
  );

create policy product_images_delete_own_folder on storage.objects
  for delete to authenticated using (
    bucket_id = 'product-images'
    and auth.uid()::text = (storage.foldername(name))[1]
  );

do $$
begin
  begin
    alter publication supabase_realtime add table public.products;
  exception
    when duplicate_object then null;
    when undefined_object then null;
  end;

  begin
    alter publication supabase_realtime add table public.product_logs;
  exception
    when duplicate_object then null;
    when undefined_object then null;
  end;
end $$;
